# Etapa 2: Variáveis e Atribuição
contador = 0
print("Valor inicial:", contador)
# Atualizando o valor da variável
contador = 5
print("Valor atualizado:", contador)