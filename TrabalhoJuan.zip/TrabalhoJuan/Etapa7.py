# Etapa 7: Interação com o Usuário
Nome_usuario = input("Digite seu nome de usuário: ")
Idade_usuario = int(input("Digite sua idade: "))
Idade_100 =  100 - Idade_usuario
# Interação com o usuário
print(f"Olá, {Nome_usuario}! seja bem vindo a etapa 7 do nosso curso de Python.")
# Cálculo de quantos anos faltam para o usuário completar 100 anos
print(f"Uma rapida demonstração do que foi aprendido é: em cerca de {Idade_100} anos, você completará 100 anos de idade.")
print(f"Esse calculo é feito subtraindo a sua idade atual de 100(100 - Idade) que nesse caso 100 - {Idade_usuario} = {Idade_100} , para descobrir quantos anos faltam para você chegar a essa marca.")