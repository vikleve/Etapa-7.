# Etapa 3: Tipos de Dados e Variáveis
nome = "victor"
idade = 18
altura = 1.80
estudante = True
# Imprimindo os valores das variáveis
print(nome)
print(idade)  
print(altura)
print(estudante)