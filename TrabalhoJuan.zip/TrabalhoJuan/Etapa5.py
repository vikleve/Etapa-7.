# Etapa 5: Operações Matemáticas
nume1 = 10
nume2 = 5
# Realizando as operações matemáticas
soma = nume1 + nume2
subtracao = nume1 - nume2
multiplicacao = nume1 * nume2
divisao = nume1 / nume2
# Exibindo os resultados
print(f"Soma: {soma}")
print(f"Subtração: {subtracao}")
print(f"Multiplicação: {multiplicacao}")
print(f"Divisão: {divisao}")