Nome_usuario = input("Digite seu nome de usuário: ")
Idade_usuario = int(input("Digite sua idade: "))
# Imprimindo a mensagem de boas-vindas usando f-strings
print(f"Olá, {Nome_usuario}! seja bem vindo ao VScode, sua idade é atualmente {Idade_usuario} anos.")