# Etapa 1: Introdução à Programação
mensagem = "Olá, Mundo!"
print(mensagem)