# Etapa 4: Formatação de Strings
nome = "victor"
idade = 18
altura = 1.80
estudante = True
# Usando f-strings para formatação
print(f"Olá, meu nome é {nome}, tenho atualmente {idade} anos, minha altura é {altura} metros e sou estudante: {estudante}.")
# Usando concatenação de strings
print('Olá, meu nome é ',  nome,  ', tenho atualmente ', idade, ' anos, minha altura é ', altura, ' metros e sou estudante: ', estudante,'.')